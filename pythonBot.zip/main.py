import discord
from discord.ext import commands
import os
import logging
from datetime import datetime
from dotenv import load_dotenv

# Configuration du logging
def setup_logging():
    """Configure le système de logging"""
    # Création du dossier logs s'il n'existe pas
    if not os.path.exists('logs'):
        os.makedirs('logs')
    
    # Configuration du format de logging
    log_format = '%(asctime)s | %(levelname)s | %(message)s'
    date_format = '%Y-%m-%d %H:%M:%S'
    
    # Création du nom de fichier avec la date
    filename = f'logs/bot_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'
    
    # Configuration du logging
    logging.basicConfig(
        level=logging.INFO,
        format=log_format,
        datefmt=date_format,
        handlers=[
            logging.FileHandler(filename, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    
    return logging.getLogger('DiscordBot')

# Chargement des variables d'environnement
load_dotenv()

# Configuration des intentions
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.reactions = True
intents.guilds = True

class DiscordBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix='!', intents=intents)
        self.logger = setup_logging()
        self.initial_cogs = [
            'cogs.vrchat_verification',
            'cogs.kill',
            'cogs.server_info',
            'cogs.welcome'
        ]

    async def setup_hook(self):
        """Configuration initiale du bot"""
        self.logger.info('Démarrage du chargement des cogs...')
        
        for cog in self.initial_cogs:
            try:
                await self.load_extension(cog)
                self.logger.info(f'✅ Cog chargé avec succès: {cog}')
            except Exception as e:
                self.logger.error(f'❌ Erreur lors du chargement de {cog}: {str(e)}')
                self.logger.exception(e)  # Log le traceback complet

        self.logger.info('Chargement des cogs terminé')

    async def on_ready(self):
        """Événement déclenché quand le bot est prêt"""
        self.logger.info('-' * 50)
        self.logger.info(f'Bot connecté en tant que {self.user.name}')
        self.logger.info(f'ID du bot: {self.user.id}')
        self.logger.info(f'Discord.py version: {discord.__version__}')
        self.logger.info(f'Nombre de serveurs: {len(self.guilds)}')
        
        # Log les serveurs connectés
        for guild in self.guilds:
            self.logger.info(f'Connecté au serveur: {guild.name} (ID: {guild.id})')
        
        # Liste toutes les commandes disponibles
        commands_list = [command.name for command in self.commands]
        self.logger.info(f'Commandes disponibles: {", ".join(commands_list)}')
        
        await self.change_presence(activity=discord.Game(name="!help"))
        self.logger.info('Status du bot mis à jour: !help')
        self.logger.info('-' * 50)

    async def on_command_error(self, ctx, error):
        """Gestion globale des erreurs de commandes"""
        if isinstance(error, commands.CommandNotFound):
            await ctx.send("❌ Cette commande n'existe pas.")
            self.logger.warning(f'Commande non trouvée: {ctx.message.content} (Utilisateur: {ctx.author})')
        elif isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ Vous n'avez pas la permission d'utiliser cette commande.")
            self.logger.warning(f'Permission manquante pour {ctx.author} sur la commande {ctx.command}')
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send("❌ Il manque un argument requis pour cette commande.")
            self.logger.warning(f'Argument manquant pour la commande {ctx.command} par {ctx.author}')
        elif isinstance(error, commands.NotOwner):
            await ctx.send("❌ Seul le propriétaire du bot peut utiliser cette commande.")
            self.logger.warning(f'Tentative d\'utilisation d\'une commande réservée par {ctx.author}')
        else:
            self.logger.error(f'Erreur non gérée dans la commande {ctx.command}:')
            self.logger.exception(error)

def main():
    """Fonction principale pour démarrer le bot"""
    # Récupération du token depuis les variables d'environnement
    token = os.getenv('DISCORD_TOKEN')
    
    if not token:
        raise ValueError("Le token Discord n'a pas été trouvé dans le fichier .env")
    
    # Création et démarrage du bot
    bot = DiscordBot()
    
    try:
        print("Démarrage du bot...")
        bot.run(token)
    except discord.LoginFailure:
        bot.logger.critical('Échec de connexion: Token Discord invalide')
    except Exception as e:
        bot.logger.critical(f'Erreur fatale lors du démarrage du bot:')
        bot.logger.exception(e)

if __name__ == '__main__':
    main()