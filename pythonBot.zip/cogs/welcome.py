import discord
from discord.ext import commands
from PIL import Image, ImageDraw, ImageFont
import io
import aiohttp
import json
import os
from pathlib import Path

class WelcomeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.welcome_config_path = 'welcome_config.json'
        self.welcome_config = self.load_welcome_config()
        self.font_path = './asset/font/NotoSans-Regular.ttf'
        
        os.makedirs('./asset/font', exist_ok=True)
        self.ensure_font_exists()

    def ensure_font_exists(self):
        noto_sans_url = "https://github.com/notofonts/notofonts.github.io/raw/main/noto-sans/NotoSans-Regular.ttf"
        if not os.path.exists(self.font_path):
            try:
                import urllib.request
                urllib.request.urlretrieve(noto_sans_url, self.font_path)
                print(f"Téléchargement de la police Noto Sans vers {self.font_path}")
            except Exception as e:
                print(f"Impossible de télécharger la police : {e}")

    def load_welcome_config(self):
        if os.path.exists(self.welcome_config_path):
            with open(self.welcome_config_path, 'r') as f:
                return json.load(f)
        return {}

    def save_welcome_config(self):
        with open(self.welcome_config_path, 'w') as f:
            json.dump(self.welcome_config, f, indent=4)

    @commands.command(name='welcome')
    @commands.has_permissions(administrator=True)
    async def setup_welcome(self, ctx, guild_id: int, room_id: int):
        guild = self.bot.get_guild(guild_id)
        if not guild:
            await ctx.send("Je ne trouve pas ce serveur.")
            return

        room = guild.get_channel(room_id)
        if not room:
            await ctx.send("Je ne trouve pas ce salon.")
            return

        self.welcome_config[str(guild_id)] = room_id
        self.save_welcome_config()
        await ctx.send(f"Salon de bienvenue configuré pour le serveur {guild.name} : {room.mention}")

    @commands.Cog.listener()
    async def on_member_join(self, member):
        welcome_channel_id = self.welcome_config.get(str(member.guild.id))
        if not welcome_channel_id:
            return

        welcome_channel = member.guild.get_channel(welcome_channel_id)
        if welcome_channel:
            try:
                welcome_image = await self.create_welcome_image(member)
                
                embed = discord.Embed(color=discord.Color.blue())
                embed.set_image(url="attachment://welcome.png")
                
                await welcome_channel.send(embed=embed, file=discord.File(welcome_image, filename="welcome.png"))
            except Exception as e:
                print(f"Erreur lors de la création de l'image de bienvenue : {e}")
                import traceback
                traceback.print_exc()

    async def create_welcome_image(self, member):
        async with aiohttp.ClientSession() as session:
            async with session.get(str(member.display_avatar.url)) as response:
                avatar_data = await response.read()
        
        avatar = Image.open(io.BytesIO(avatar_data)).convert("RGBA")
        avatar = avatar.resize((160, 160))
        
        background = Image.new('RGBA', (704, 160), color=(47, 49, 54))
        
        draw = ImageDraw.Draw(background)
        
        background.paste(avatar, (0, 0), avatar)
        
        try:
            font_medium = ImageFont.truetype(self.font_path, 32)
            font_small = ImageFont.truetype(self.font_path, 24)
            
            draw.text((180, 20), "Bienvenue", font=font_medium, fill=(255, 255, 255))
            draw.text((180, 60), "sur le serveur de", font=font_small, fill=(200, 200, 200))
            draw.text((180, 90), "Reborn Tool", font=font_small, fill=(200, 200, 200))
        except Exception as e:
            print(f"Erreur de police : {e}")
            draw.text((180, 20), "Bienvenue", fill=(255, 255, 255))
            draw.text((180, 60), "sur le serveur de", fill=(200, 200, 200))
            draw.text((180, 90), "Reborn Tool", fill=(200, 200, 200))
        
        img_byte_arr = io.BytesIO()
        background.save(img_byte_arr, format='PNG')
        img_byte_arr.seek(0)
        
        return img_byte_arr

async def setup(bot):
    await bot.add_cog(WelcomeCog(bot))