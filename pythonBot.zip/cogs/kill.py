import sys
import discord
from discord.ext import commands

class KillCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='kill')
    @commands.is_owner()
    async def kill_bot(self, ctx):
        """Éteint proprement le bot"""
        await ctx.send("🔌 Arrêt du bot en cours...")
        self.bot.logger.info(f'Bot arrêté manuellement par {ctx.author}')
        await self.bot.close()
        sys.exit(0)

async def setup(bot):
    await bot.add_cog(KillCog(bot))