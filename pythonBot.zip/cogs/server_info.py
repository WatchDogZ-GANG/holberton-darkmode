import discord
from discord.ext import commands
import json
import os
import asyncio

class ServerInfoCog(commands.Cog):
   def __init__(self, bot):
       self.bot = bot
       self.server_info_file = 'servers_info.json'

   @commands.Cog.listener()
   async def on_ready(self):
       server_data = []

       for guild in self.bot.guilds:
           guild_info = {
               "guildName": guild.name,
               "guildID": str(guild.id),
               "roles": {},
               "createur": {},
               "admins": [],
               "users": [],
               "permanentJoinLinks": [],
               "joinLinks": []
           }

           for role in guild.roles:
               guild_info["roles"][f"roleID{role.id}"] = str(role.id)
               guild_info["roles"][f"roleName{role.id}"] = role.name

           if guild.owner:
               guild_info["createur"] = {
                   "createurUserID": str(guild.owner.id),
                   "createurUserName": guild.owner.name,
                   "createurUser": str(guild.owner)
               }

           admin_roles = [role for role in guild.roles if role.permissions.administrator]
           for role in admin_roles:
               for member in role.members:
                   admin_info = {
                       "adminUserID": str(member.id),
                       "adminUserName": member.name,
                       "adminUser": str(member)
                   }
                   if admin_info not in guild_info["admins"]:
                       guild_info["admins"].append(admin_info)

           for member in guild.members:
               if not member.bot:
                   user_info = {
                       "userID": str(member.id),
                       "userName": member.name,
                       "user": str(member)
                   }
                   if user_info not in guild_info["users"]:
                       guild_info["users"].append(user_info)

           try:
               invites = await guild.invites()
               permanent_invites = [inv.url for inv in invites if inv.max_age == 0]
               non_permanent_invites = [inv.url for inv in invites if inv.max_age != 0]
               
               guild_info["permanentJoinLinks"] = permanent_invites
               guild_info["joinLinks"] = non_permanent_invites
           except discord.Forbidden:
               self.bot.logger.warning(f"Impossible de récupérer les invitations pour {guild.name}")

           server_data.append(guild_info)

       with open(self.server_info_file, 'w', encoding='utf-8') as f:
           json.dump(server_data, f, indent=4, ensure_ascii=False)

       self.bot.logger.info(f"Informations des serveurs sauvegardées dans {self.server_info_file}")

   @commands.command(name='serverinfo')
   @commands.is_owner()
   async def server_info_command(self, ctx):
       try:
           with open(self.server_info_file, 'r', encoding='utf-8') as f:
               servers = json.load(f)
       except FileNotFoundError:
           await ctx.send("Aucune information de serveur n'a été trouvée. Utilisez la commande après le démarrage du bot.")
           return

       server_count = len(servers)
       current_server_index = 0

       while current_server_index < server_count:
           server = servers[current_server_index]
           guild = self.bot.get_guild(int(server['guildID']))

           embed = discord.Embed(title=server['guildName'], color=discord.Color.blue())

           if guild and guild.icon:
               embed.set_thumbnail(url=guild.icon.url)

           createur = server.get('createur', {})
           embed.add_field(name="👑 Créateur", 
                           value=f"{createur.get('createurUserName', 'N/A')} (`{createur.get('createurUserID', 'N/A')}`)", 
                           inline=False)

           # Rôles
           roles = server.get('roles', {})
           role_names = {key: value for key, value in roles.items() if key.startswith('roleName')}
           role_ids = {key: value for key, value in roles.items() if key.startswith('roleID')}

           role_list = "\n".join([f"`{role_names.get(f'roleName{role_id}')}` ({role_id})" 
                                  for role_id in role_ids.values()])
           if role_list:
               embed.add_field(name="🏷️ Rôles", value=role_list, inline=False)

           # Admins
           admins = server.get('admins', [])
           admins = [admin for admin in admins if admin.get('adminUserID') != createur.get('createurUserID')]
           if admins:
               admin_list = "\n".join([f"{admin['adminUserName']} (`{admin['adminUserID']}`)" for admin in admins])
               embed.add_field(name="🛡️ Admins", value=admin_list, inline=False)

           # Utilisateurs
           users = server.get('users', [])
           excluded_ids = [createur.get('createurUserID', '')] + [admin.get('adminUserID', '') for admin in admins]
           users = [user for user in users if user.get('userID') not in excluded_ids]

           if users:
               user_list = "\n".join([f"{user['userName']} (`{user['userID']}`)" for user in users])
               embed.add_field(name="👥 Utilisateurs", value=user_list, inline=False)

           # Liens permanents
           permanent_links = server.get('permanentJoinLinks', [])
           if permanent_links:
               perma_links = "\n".join([f"[Lien {i+1}](https://discord.com/invite/{link.split('/')[-1]})" 
                                         for i, link in enumerate(permanent_links)])
               embed.add_field(name="🔒 Liens Permanents", value=perma_links, inline=False)

           # Liens non permanents
           non_permanent_links = server.get('joinLinks', [])
           if non_permanent_links:
               non_perma_links = "\n".join([f"[Lien {i+1}](https://discord.com/invite/{link.split('/')[-1]})" 
                                             for i, link in enumerate(non_permanent_links)])
               embed.add_field(name="⏳ Liens Temporaires", value=non_perma_links, inline=False)

           embed.set_footer(text=f"Serveur {current_server_index + 1}/{server_count}")

           await ctx.send(embed=embed)

           current_server_index += 1

           if current_server_index < server_count:
               await ctx.send("Appuyez sur ✅ pour voir le serveur suivant ou ❌ pour arrêter.")
               
               try:
                   reaction, user = await self.bot.wait_for(
                       'reaction_add', 
                       check=lambda r, u: u == ctx.author and str(r.emoji) in ['✅', '❌'],
                       timeout=30.0
                   )

                   if str(reaction.emoji) == '❌':
                       break
               except asyncio.TimeoutError:
                   await ctx.send("Temps écoulé. Fin de l'affichage des serveurs.")
                   break

async def setup(bot):
   await bot.add_cog(ServerInfoCog(bot))