import discord
from discord.ext import commands
from discord import ui
import aiohttp
import asyncio
from datetime import datetime, timedelta
import os
import sys
import json
import traceback
from dotenv import load_dotenv

load_dotenv()


class CookieManager:
    def __init__(self, cookie_file=None):
        # Use a default path if no file is specified
        if cookie_file is None:
            # Ensure the directory exists
            config_dir = os.path.expanduser("~/.config/vrchat_discord_bot")
            os.makedirs(config_dir, exist_ok=True)
            cookie_file = os.path.join(config_dir, "cookies.json")
        
        self.cookie_file = cookie_file
        self.cookies = self.load_cookies()

    def load_cookies(self):
        """Load cookies from a JSON file"""
        try:
            if os.path.exists(self.cookie_file):
                with open(self.cookie_file, 'r') as f:
                    cookies_data = json.load(f)
                    
                    # Validate the structure of cookies_data
                    if not isinstance(cookies_data, dict):
                        print("❌ Invalid cookies data format.")
                        return {}
                    
                    # Check if cookies are still valid (not older than 7 days)
                    timestamp_str = cookies_data.get('timestamp', '2000-01-01')
                    try:
                        timestamp = datetime.fromisoformat(timestamp_str)
                        if (datetime.now() - timestamp).days < 7:
                            return cookies_data
                    except ValueError:
                        print(f"❌ Invalid timestamp: {timestamp_str}")
                    
                    print("🕒 Stored cookies have expired or are invalid.")
                    return {}
            return {}
        except (json.JSONDecodeError, IOError) as e:
            print(f"❌ Error loading cookies: {e}")
            return {}

    def save_cookies(self, auth_cookie=None, two_factor_cookie=None):
        """Save cookies to a JSON file with detailed logging"""
        try:
            # Extensive logging before saving
            print("🔐 Attempting to save cookies:")
            
            # Function to extract cookie value
            def extract_cookie_value(cookie):
                if hasattr(cookie, 'value'):
                    return cookie.value
                elif isinstance(cookie, str):
                    return cookie
                elif isinstance(cookie, dict):
                    return cookie.get('value', str(cookie))
                return str(cookie)

            # Extract cookie values
            auth_value = extract_cookie_value(auth_cookie)
            two_factor_value = extract_cookie_value(two_factor_cookie) if two_factor_cookie else None

            print(f"Auth Cookie (processed value): {auth_value}")
            print(f"Two Factor Cookie (processed value): {two_factor_value}")

            # Only save if auth_cookie is present
            if not auth_value:
                print("❌ Cannot save cookies: Missing auth cookie")
                return False

            cookies_data = {
                'timestamp': datetime.now().isoformat(),
                'auth_cookie': auth_value,
                'two_factor_cookie': two_factor_value
            }
            
            # Ensure the directory exists
            os.makedirs(os.path.dirname(self.cookie_file), exist_ok=True)
            
            # Save with pretty formatting for readability
            with open(self.cookie_file, 'w') as f:
                json.dump(cookies_data, f, indent=2)
            
            print(f"✅ Cookies saved successfully to {self.cookie_file}")
            return True
        except Exception as e:
            print(f"❌ Error saving cookies: {type(e).__name__} - {e}")
            # Print full traceback
            traceback.print_exc()
            return False

    def get_stored_cookies(self):
        """Retrieve stored cookies with detailed logging"""
        print("🕵️ Debugging stored cookies:")
        print(f"Full cookies dictionary: {self.cookies}")
        print(f"Cookie file path: {self.cookie_file}")
        
        auth_cookie = self.cookies.get('auth_cookie')
        two_factor_cookie = self.cookies.get('two_factor_cookie')
        
        print(f"🍪 Retrieved auth_cookie: {auth_cookie}")
        print(f"🍪 Retrieved two_factor_cookie: {two_factor_cookie}")
        
        if not auth_cookie:
            print("❌ No stored auth cookie found.")
            return None, None
        
        return auth_cookie, two_factor_cookie


class VRChatAPI:
    def __init__(self, bot):
        self.bot = bot
        self.session = None
        self.api_base = "https://api.vrchat.cloud/api/1"
        self.cookies = {}
        self.auth_cookie = None
        self.two_factor_cookie = None
        self.waiting_for_2fa = False
        self.headers = {
            "User-Agent": "VRChat Discord Bot/1.0",
            "Content-Type": "application/json",
        }
        self.cookie_manager = CookieManager()

    def create_auth_header(self, username, password):
        """Crée le header d'authentification en Base64"""
        import urllib.parse
        import base64

        encoded_username = urllib.parse.quote(username)
        encoded_password = urllib.parse.quote(password)
        auth_string = f"{encoded_username}:{encoded_password}"
        auth_bytes = auth_string.encode("ascii")
        base64_auth = base64.b64encode(auth_bytes).decode("ascii")

        return f"Basic {base64_auth}"

    async def validate_stored_cookies(self):
        """Valide les cookies stockés avec des diagnostics détaillés"""
        try:
            # Création de la session si nécessaire
            if not self.session or self.session.closed:
                self.session = aiohttp.ClientSession()

            # Vérification des cookies
            if not self.auth_cookie:
                print("❌ Aucun cookie d'authentification trouvé.")
                return False

            print(f"🕵️ Tentative de validation du cookie auth: {self.auth_cookie}")
            print(f"🕵️ Cookie 2FA: {self.two_factor_cookie}")

            headers = {**self.headers}
            headers["Cookie"] = f"auth={self.auth_cookie}"

            if self.two_factor_cookie:
                headers["Cookie"] += f"; twoFactorAuth={self.two_factor_cookie}"

            # Ajouter des en-têtes supplémentaires pour déboguer
            headers["User-Agent"] = "VRChat Discord Bot/1.0 (Debugging)"

            try:
                async with self.session.get(
                    f"{self.api_base}/auth/user", 
                    headers=headers,
                    timeout=10  # Timeout de 10 secondes
                ) as response:
                    print(f"🔍 Status de la réponse: {response.status}")
                    
                    # Afficher les en-têtes de réponse
                    print("🧾 En-têtes de réponse:")
                    for key, value in response.headers.items():
                        print(f"  {key}: {value}")

                    if response.status == 200:
                        # Tenter de lire le contenu de la réponse
                        try:
                            response_content = await response.text()
                            print("📄 Contenu de la réponse:")
                            print(response_content[:500])  # Afficher les 500 premiers caractères
                        except Exception as content_error:
                            print(f"❌ Erreur de lecture du contenu: {content_error}")

                        print("✅ Cookies stockés validés avec succès.")
                        return True
                    
                    # Tenter de lire le contenu en cas d'erreur
                    try:
                        error_content = await response.text()
                        print(f"❌ Contenu de l'erreur: {error_content}")
                    except Exception as content_error:
                        print(f"❌ Impossible de lire le contenu de l'erreur: {content_error}")

                    print("❌ Cookies stockés invalides.")
                    self.auth_cookie = None
                    self.two_factor_cookie = None
                    return False

            except aiohttp.ClientError as client_error:
                print(f"🚨 Erreur de connexion client: {client_error}")
                return False
            except asyncio.TimeoutError:
                print("⏰ Délai de connexion dépassé")
                return False

        except Exception as e:
            print(f"❌ Erreur lors de la validation des cookies: {type(e).__name__} - {e}")
            # Réinitialisation des cookies en cas d'erreur
            self.auth_cookie = None
            self.two_factor_cookie = None
            return False

    async def init_session(self):
        """Initialise la session avec authentification"""
        try:
            # Vérification si la session est déjà valide
            if (
                self.session
                and not self.session.closed
                and self.auth_cookie
                and self.two_factor_cookie
                and not self.waiting_for_2fa
            ):
                return True

            # Essayer d'utiliser les cookies stockés
            stored_auth_cookie, stored_two_factor_cookie = self.cookie_manager.get_stored_cookies()
            
            if stored_auth_cookie:
                print("🍪 Tentative d'utilisation des cookies stockés")
                self.auth_cookie = stored_auth_cookie
                self.two_factor_cookie = stored_two_factor_cookie
                
                # Vérifier la validité des cookies stockés
                if await self.validate_stored_cookies():
                    return True

            # Récupération des identifiants
            username = os.getenv("VRCHAT_USER")
            password = os.getenv("VRCHAT_PASS")

            if not username or not password:
                raise ValueError("Identifiants VRChat manquants dans .env")

            # Création de la session si nécessaire
            if not self.session or self.session.closed:
                self.session = aiohttp.ClientSession()

            # Préparation de l'authentification
            auth_header = self.create_auth_header(username, password)
            headers = {**self.headers, "Authorization": auth_header}

            async with self.session.get(
                f"{self.api_base}/auth/user", headers=headers
            ) as response:
                if response.status == 200:
                    # Extraire les cookies de la réponse
                    cookies = response.cookies
                    self.auth_cookie = cookies.get("auth")
                    data = await response.json()

                    # Gestion de l'authentification à deux facteurs
                    if data.get("requiresTwoFactorAuth"):
                        self.waiting_for_2fa = True
                        print("🔐 Authentification à deux facteurs requise.")
                        return await self.handle_two_factor_auth()

                    # Sauvegarde des nouveaux cookies
                    if self.auth_cookie:
                        self.cookie_manager.save_cookies(
                            auth_cookie=self.auth_cookie,
                            two_factor_cookie=self.two_factor_cookie
                        )

                    self.bot.logger.info(
                        f"Authentification réussie pour: {data.get('displayName', 'Unknown')}"
                    )
                    return True
                else:
                    content = await response.text()
                    raise Exception(
                        f"Échec de l'authentification: {response.status}, {content}"
                    )

        except Exception as e:
            self.bot.logger.error(f"Erreur lors de l'initialisation VRChat: {str(e)}")
            if self.session and not self.session.closed:
                await self.session.close()
            raise

    async def handle_two_factor_auth(self):
        """Gère l'authentification à deux facteurs via le terminal"""
        try:
            if not self.auth_cookie:
                raise Exception("Pas de cookie d'authentification")

            # Demande du code 2FA dans le terminal
            while True:
                code = input("📧 Entrez le code de vérification reçu par email (6 chiffres): ").strip()
                
                # Validation basique du code
                if not code or not code.isdigit() or len(code) != 6:
                    print("❌ Code invalide. Doit contenir 6 chiffres.")
                    continue

                headers = {**self.headers, "Cookie": f"auth={self.auth_cookie}"}
                data = {"code": code}

                async with self.session.post(
                    f"{self.api_base}/auth/twofactorauth/emailotp/verify",
                    headers=headers,
                    json=data,
                ) as response:
                    if response.status == 200:
                        cookies = response.cookies
                        self.two_factor_cookie = cookies.get("twoFactorAuth")
                        if self.two_factor_cookie:
                            print("✅ Authentification à deux facteurs réussie.")
                            self.waiting_for_2fa = False
                            
                            # Sauvegarde des cookies
                            self.cookie_manager.save_cookies(
                                auth_cookie=self.auth_cookie,
                                two_factor_cookie=self.two_factor_cookie
                            )
                            
                            return True
                        else:
                            print("❌ Cookie 2FA non trouvé.")
                    else:
                        content = await response.text()
                        print(f"❌ Échec de la vérification 2FA: {response.status}, {content}")
                        retry = input("Voulez-vous réessayer ? (O/n): ").lower().strip()
                        if retry != 'o':
                            sys.exit("Authentification annulée.")

        except Exception as e:
            print(f"❌ Erreur lors de la vérification 2FA: {str(e)}")
            sys.exit("Échec de l'authentification.")

    async def search_users(self, search_query, developer_type=None, limit=25, offset=0):
        """Recherche des utilisateurs VRChat"""
        try:
            auth_result = await self.init_session()
            if not auth_result:
                if self.waiting_for_2fa:
                    return {"requires_2fa": True}
                return []

            params = {
                "search": search_query,
                "n": min(100, max(1, limit)),
                "offset": max(0, offset),
            }
            if developer_type:
                params["developerType"] = developer_type

            headers = {**self.headers, "Cookie": f"auth={self.auth_cookie}"}
            if self.two_factor_cookie:
                headers["Cookie"] += f"; twoFactorAuth={self.two_factor_cookie}"

            async with self.session.get(
                f"{self.api_base}/users", params=params, headers=headers
            ) as response:
                if response.status == 200:
                    users = await response.json()
                    self.bot.logger.info(
                        f"Recherche réussie: {len(users)} utilisateurs trouvés"
                    )
                    return users
                else:
                    content = await response.text()
                    self.bot.logger.error(
                        f"Erreur recherche VRChat: {response.status}, {content}"
                    )
                    if response.status == 401:
                        self.auth_cookie = None
                        self.two_factor_cookie = None
                        return await self.search_users(
                            search_query, developer_type, limit, offset
                        )
                    return []

        except Exception as e:
            self.bot.logger.error(f"Erreur lors de la recherche: {str(e)}")
            return []

    async def close(self):
        """Ferme la session"""
        if self.session and not self.session.closed:
            await self.session.close()

class TwoFactorModal(ui.Modal, title="Vérification 2FA"):
    def __init__(self, cog, callback):
        super().__init__()
        self.cog = cog
        self.callback = callback
        self.code = ui.TextInput(
            label="Code 2FA",
            placeholder="Entrez le code reçu par email...",
            min_length=6,
            max_length=6,
            required=True,
            style=discord.TextStyle.short,
        )
        self.add_item(self.code)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            verified = await self.cog.vrchat_api.verify_2fa(self.code.value)
            if verified:
                await self.callback(interaction)
            else:
                await interaction.followup.send(
                    "❌ Code 2FA invalide. Veuillez réessayer avec !verify",
                    ephemeral=True,
                )
        except Exception as e:
            self.cog.bot.logger.error(f"Erreur lors de la vérification 2FA: {str(e)}")
            await interaction.followup.send(
                "❌ Une erreur s'est produite lors de la vérification 2FA.",
                ephemeral=True,
            )


class SearchView(discord.ui.View):
    def __init__(self, cog, timeout=180):
        super().__init__(timeout=timeout)
        self.cog = cog

    @discord.ui.button(
        label="🔍 Rechercher un profil VRChat", style=discord.ButtonStyle.primary
    )
    async def search(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = SearchModal(self.cog)
        await interaction.response.send_modal(modal)


class SearchModal(ui.Modal, title="Recherche VRChat"):
    def __init__(self, cog, offset=0):
        super().__init__()
        self.cog = cog
        self.offset = offset
        self.results_per_page = 25
        self.query = ui.TextInput(
            label="Nom d'utilisateur VRChat",
            placeholder="Entrez votre nom d'utilisateur...",
            min_length=3,
            max_length=50,
            required=True,
            style=discord.TextStyle.short,
        )
        self.add_item(self.query)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            users = await self.cog.vrchat_api.search_users(
                search_query=self.query.value,
                limit=self.results_per_page,
                offset=self.offset,
            )

            if isinstance(users, dict) and users.get("requires_2fa"):
                modal = TwoFactorModal(self.cog, lambda i: self.on_submit(i))
                await interaction.followup.send(
                    "📧 Un code de vérification a été envoyé à votre email VRChat.",
                    ephemeral=True,
                )
                await interaction.followup.send_modal(modal)
                return

            if not users:
                await interaction.followup.send(
                    "❌ Aucun utilisateur trouvé avec ce nom.", ephemeral=True
                )
                return

            options = [
                discord.SelectOption(
                    label=user.get("displayName", "Unknown")[:100],
                    value=user.get("id"),
                    description=f"Status: {user.get('status', 'Unknown')}",
                )
                for user in users[:25]
            ]

            # Création du menu de sélection
            select = discord.ui.Select(
                placeholder="Choisissez votre profil...", options=options
            )

            async def select_callback(select_interaction):
                selected_id = select_interaction.data["values"][0]
                selected_user = next(
                    (user for user in users if user.get("id") == selected_id), None
                )

                if not selected_user:
                    return

                embed = discord.Embed(
                    title="📋 Profil sélectionné", color=discord.Color.green()
                )
                embed.add_field(
                    name="Nom d'utilisateur",
                    value=selected_user.get("displayName", "Unknown"),
                    inline=True,
                )
                embed.add_field(
                    name="Status",
                    value=selected_user.get("status", "Unknown"),
                    inline=True,
                )
                if selected_user.get("bio"):
                    embed.add_field(
                        name="Bio", value=selected_user.get("bio"), inline=False
                    )

                view = ConfirmView(self.cog, selected_user)
                await select_interaction.response.edit_message(embed=embed, view=view)

            select.callback = select_callback

            view = discord.ui.View(timeout=180)
            view.add_item(select)

            # Ajout des boutons de pagination si nécessaire
            if len(users) >= 25:
                next_button = discord.ui.Button(
                    label="Suivant ➡️", style=discord.ButtonStyle.gray, custom_id="next"
                )

                async def next_callback(next_interaction):
                    modal = SearchModal(self.cog, offset=self.offset + 25)
                    await next_interaction.response.send_modal(modal)

                next_button.callback = next_callback
                view.add_item(next_button)

            if self.offset > 0:
                prev_button = discord.ui.Button(
                    label="⬅️ Précédent",
                    style=discord.ButtonStyle.gray,
                    custom_id="prev",
                )

                async def prev_callback(prev_interaction):
                    modal = SearchModal(self.cog, offset=max(0, self.offset - 25))
                    await prev_interaction.response.send_modal(modal)

                prev_button.callback = prev_callback
                view.add_item(prev_button)

            embed = discord.Embed(
                title="Résultats de la recherche",
                description=f"📝 {len(users)} profil(s) trouvé(s)\nPage {(self.offset // 25) + 1}",
                color=discord.Color.blue(),
            )

            await interaction.followup.send(embed=embed, view=view, ephemeral=True)

        except Exception as e:
            self.cog.bot.logger.error(f"Erreur lors de la recherche: {str(e)}")
            await interaction.followup.send(
                "❌ Une erreur s'est produite lors de la recherche.", ephemeral=True
            )


class ConfirmView(discord.ui.View):
    def __init__(self, cog, user_data, timeout=180):
        super().__init__(timeout=timeout)
        self.cog = cog
        self.user_data = user_data

    @discord.ui.button(label="✅ Confirmer", style=discord.ButtonStyle.green)
    async def confirm(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        await self.cog.validate_user(interaction, self.user_data)

    @discord.ui.button(label="❌ Annuler", style=discord.ButtonStyle.red)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            content="Vérification annulée. Utilisez !verify pour recommencer.",
            embed=None,
            view=None,
        )


class VRChatVerification(commands.Cog, name="VRChatVerification"):
    def __init__(self, bot):
        self.bot = bot
        self.vrchat_api = VRChatAPI(bot)
        self.bot.logger.info("Cog VRChatVerification initialisé")
        
        # Authentification au démarrage
        asyncio.create_task(self.startup_authentication())

    async def startup_authentication(self):
        """Effectue l'authentification au démarrage du bot"""
        try:
            print("🌐 Tentative d'authentification VRChat...")
            await self.vrchat_api.init_session()
            print("✅ Authentification VRChat réussie.")
        except Exception as e:
            print(f"❌ Échec de l'authentification VRChat: {e}")
            sys.exit("Impossible de se connecter à VRChat.")

    @commands.command(name="verify", help="Lance le processus de vérification VRChat")
    @commands.guild_only()
    async def verify(self, ctx):
        """Lance le processus de vérification VRChat"""
        self.bot.logger.info(f"Commande verify appelée par {ctx.author}")

        # Vérifie si l'utilisateur est déjà vérifié
        verified_roles = ["Visitor", "New User", "User", "Known User", "Trusted User"]
        if any(role.name in verified_roles for role in ctx.author.roles):
            await ctx.send("⚠️ Vous êtes déjà vérifié !", ephemeral=True)
            return

        embed = discord.Embed(
            title="🔍 Vérification VRChat",
            description="Pour commencer la vérification, cliquez sur le bouton ci-dessous.",
            color=discord.Color.blue(),
        )

        view = SearchView(self)
        await ctx.send(embed=embed, view=view, ephemeral=True)

    def get_trust_level(self, user_data):
        """Détermine le niveau de confiance VRChat"""
        trust_levels = {
            "visitor": "Visitor",
            "new_user": "New User",
            "user": "User",
            "known": "Known User",
            "trusted": "Trusted User",
        }
        status = user_data.get("status", "visitor").lower()
        return trust_levels.get(status, "Visitor")

    async def validate_user(self, interaction, user_data):
        """Valide un utilisateur et configure son rôle"""
        member = interaction.user
        guild = interaction.guild

        embed = discord.Embed(
            title="✅ Nouveau membre vérifié",
            color=discord.Color.green(),
            timestamp=datetime.now(),
        )
        embed.add_field(name="Discord", value=member.mention, inline=True)
        embed.add_field(
            name="VRChat", value=user_data.get("displayName", "Unknown"), inline=True
        )

        # Détermination et attribution du rôle
        role_name = self.get_trust_level(user_data)
        embed.add_field(name="Trust Level", value=role_name, inline=True)

        if user_data.get("bio"):
            embed.add_field(name="Bio", value=user_data.get("bio"), inline=False)

        # Attribution du rôle
        role = discord.utils.get(guild.roles, name=role_name)
        if role:
            try:
                await member.add_roles(role)
                self.bot.logger.info(f"Rôle {role_name} attribué à {member.name}")
            except discord.Forbidden:
                self.bot.logger.error(
                    f"Impossible d'attribuer le rôle {role_name} à {member.name}"
                )

        # Changement du pseudo
        try:
            await member.edit(nick=user_data.get("displayName"))
            self.bot.logger.info(
                f"Pseudo de {member.name} changé en {user_data.get('displayName')}"
            )
        except discord.Forbidden:
            self.bot.logger.error(f"Impossible de changer le pseudo de {member.name}")

        # Envoi dans le salon de logs
        log_channel = discord.utils.get(guild.channels, name="verification-logs")
        if log_channel:
            await log_channel.send(embed=embed)
            self.bot.logger.info(f"Log de vérification envoyé pour {member.name}")

        # Message de confirmation à l'utilisateur
        confirm_embed = discord.Embed(
            title="✅ Vérification terminée",
            description=f"Vous avez reçu le rôle {role_name}",
            color=discord.Color.green(),
        )
        await interaction.response.edit_message(embed=confirm_embed, view=None)

    def cog_unload(self):
        """Nettoyage lors du déchargement du cog"""
        if self.vrchat_api:
            asyncio.create_task(self.vrchat_api.close())
            self.bot.logger.info("Session VRChat fermée")


async def setup(bot):
    """Configuration du cog"""
    await bot.add_cog(VRChatVerification(bot))
    bot.logger.info("VRChatVerification cog ajouté")